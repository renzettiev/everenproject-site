import React from "react";
import { motion } from "framer-motion";
import "../App.css";

const HeroSection = () => {
  return (
    <section className="hero">
      <motion.h1
        className="logo"
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.5 }}
      >
        EVEREN PROJECT
      </motion.h1>

      <motion.h2
        className="subtitle"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.8, delay: 0.6 }}
      >
        From idea to product.
      </motion.h2>

      <motion.p
        className="tagline"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 2, delay: 1.2 }}
      >
        For your product.
      </motion.p>
    </section>
  );
};

export default HeroSection;